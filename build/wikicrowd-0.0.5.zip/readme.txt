----------------------------------------------------
  
            WikiCrowd installation guide

----------------------------------------------------

  SYSTEM REQUIREMENTS: 
     PHP 5.2 or higher with DOM, XSL and iconv 
     support.
  

  INSTALLATION:

  1. Copy install.php file to the path
     where you want to install WikiCrowd.

     For example: /var/www/wiki/install.php

  2. Access it from your browser.

  	 For example: http://mysite.com/wiki/install.php

  3. If your system environment doesn't fit to 
     WikiCrowd needs, installation will warn you.

  4. Correct web-site title, home page and support 
     e-mail address if required.
     
  5. Press "Install" button and enjoy :).


  NOTES:

  *  WikiCrowd used Apache mod_rerite to short page 
     URLs. If your web server doesn't support 
     mod_rewrite, WikiCrowd wont work yet. 
     I appologize for inconvinience.



  If you have any questions, feel free to ask me
  Stas Davydov <davidovsv@yandex.ru> or check
  the WikiCrowd FAQ for help on 
  http://wikicrowd.sourceforge.net/faq


